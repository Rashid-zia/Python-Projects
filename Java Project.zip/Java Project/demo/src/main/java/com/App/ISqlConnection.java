package com.App;

import java.sql.Connection;
import java.sql.ResultSet;

public interface ISqlConnection {
    Connection connectToDb(String dbServer, int dbPort, String dbName, String userName, String password);

    ResultSet getMovie(Connection conn);

    int addMovie(Connection conn, String movieName, float Duration, String movieSummary);

    ResultSet searchMovies(Connection conn, String search_text, String filter_type);

    ResultSet getMovie(Connection conn, String newSummary);

    int UpdateMovieByName(Connection conn, String movieName, String newMovieName);

    int updateMovie(Connection conn, String movie_Name, float duration_edit, String summary_edit, int id);

    int deleteMovie(Connection conn, int id);
}
