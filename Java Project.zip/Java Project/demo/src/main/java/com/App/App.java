package com.App;

import java.sql.ResultSet;
import java.sql.Connection;
import java.util.Scanner;

public class App {
    static String DBSERVER = "utbserver.database.windows.net";
    static int DBPORT = 1433;
    static String DBNAME = "utb-database";
    static String USERNAME = "utbadmin@utbserver";
    static String PASSWORD = "UTB_user123";

    public static void main(String[] args) {

        SqlConnection sqlConn = new SqlConnection();
        Connection conn = sqlConn.connectToDb(DBSERVER, DBPORT, DBNAME, USERNAME, PASSWORD);

        Scanner scanner = new Scanner(System.in);
        try {
            listDisplayMain(sqlConn, conn, scanner);
        } catch (Exception e) {
            listDisplayMain(sqlConn, conn, scanner);
        }
    }

    private static void listDisplayMain(SqlConnection sqlConn, Connection conn, Scanner scanner) {
        while (true) {
            System.out.println("===== Movie Management System =====");
            System.out.println("1. Create Movie");
            System.out.println("2. Update Movie");
            System.out.println("3. Show All Movies");
            System.out.println("4. Search Movie");
            System.out.println("5. Delete Movie by ID");
            System.out.println("6. Exit");

            System.out.println("===================================");
            System.out.print("Enter your choice: ");
            int choice = scanner.nextInt();

            switch (choice) {
                case 1:
                    System.out.println("Create Movie ");
                    System.out.print("Enter your movie Name: ");
                    scanner.nextLine();
                    String movieName = scanner.nextLine();

                    System.out.print("Enter your movie Summary: ");
                    String summary = scanner.nextLine();
                    float duration;
                    try {

                        System.out.print("Enter your Movie Duration ");
                        duration = scanner.nextFloat();
                    } catch (Exception e) {
                        System.out.println("Please enter only Numerical values");
                        System.out.print("Enter your Movie Duration ");
                        scanner.nextLine();
                        duration = scanner.nextFloat();
                    }

                    createMovie(sqlConn, conn, movieName, duration, summary);

                    break;
                case 2:
                    System.out.println("edit Movie ");
                    listUpdateMovie(sqlConn, conn);
                    System.out.print("Enter your Movie Id ");
                    int id = scanner.nextInt();
                    System.out.print("Enter edit movie Name: ");
                    scanner.nextLine();
                    String movie_Name = scanner.nextLine();

                    System.out.print("Enter your  movie Summary: ");
                    String summary_edit = scanner.nextLine();

                    System.out.print("Enter your Movie Duration ");
                    float duration_edit = scanner.nextFloat();

                    updateMovie(sqlConn, conn, movie_Name, duration_edit, summary_edit, id);

                    break;
                case 3:
                    System.out.println("show all  Movie ");
                    SqlConnection sql = new SqlConnection();
                    getMovies(sql, conn);
                    sql.getMovies(conn);

                    break;
                case 4:
                    System.out.println("show movie by search");
                    listDisplaySearch(sqlConn, conn);
                    break;
                case 5:

                    System.out.println("Delete Movie by ID");
                    System.out.print("Enter the Movie ID: ");
                    int deleteMovieId = scanner.nextInt();
                    deleteMovieId(conn, deleteMovieId);
                    break;

                case 6:
                    System.out.println("Exiting the program. Goodbye!");
                    // Close the connection
                    closeConnection(conn);
                    System.exit(0);
                default:
                    System.out.println("Invalid choice. Please try again.");
            }
        }
    }

    private static void deleteMovieId(Connection conn, int deleteMovieId) {
        SqlConnection sqlConn = new SqlConnection();
        int result = sqlConn.deleteMovie(conn, deleteMovieId);

        if (result > 0) {
            System.out.println("Movie with ID " + deleteMovieId + " deleted successfully.");
        } else {
            System.out.println("No movie found with ID " + deleteMovieId + ".");
        }
    }

    private static void listDisplaySearch(SqlConnection sqlConn, Connection conn) {
        while (true) {
            System.out.println("===== Movie Management System =====");
            System.out.println("1. Search Movie By Name");
            System.out.println("2. Search Movie By Summary");
            System.out.println("3. Go Back to Main Menu");

            System.out.println("===================================");
            System.out.print("Enter your choice: ");
            Scanner scanner = new Scanner(System.in);
            int choice = scanner.nextInt();

            String filter_type;

            switch (choice) {
                case 1:
                    filter_type = "movie_name";
                    System.out.println("Please enter Movie name");
                    String text = scanner.next();
                    searchMovies(sqlConn, conn, text, filter_type);
                    break;
                case 2:
                    filter_type = "summary";
                    System.out.println("Please enter Movie Summary ");
                    String movieSummary = scanner.next();
                    searchMovies(sqlConn, conn, movieSummary, filter_type);
                    break;

                case 3:
                    listDisplayMain(sqlConn, conn, scanner);
                    break;

                default:
                    System.out.println("Invalid choice. Please try again.");

            }
        }
    }

    private static void searchMovies(SqlConnection sqlConn, Connection conn, String search_text, String filter_type) {

        try

        {
            ResultSet data;
            data = sqlConn.searchMovies(conn, search_text, filter_type);
            if (!data.next()) {
                System.out.println("No matching records found");

            }

            else {

                String Name;
                float Duration;
                String Summary;
                int id;
                System.out.println("ID\tNAME\tDURATION\tSUMMARY");
                while (data.next()) {
                    Name = data.getString("Name");
                    Duration = data.getFloat("Duration");
                    Summary = data.getString("Summary");
                    id = data.getInt("Id");

                    System.out.println(id + "\t" + Name + "\t" + Duration + "\t" + Summary);

                }
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    // update movie
    private static void listUpdateMovie(SqlConnection sqlConn, Connection conn) {
        boolean loop = true;
        while (loop) {
            System.out.println("===== Please Select Movie First =====");
            System.out.println("1. Search Movie By Name");
            System.out.println("2. Search Movie By Summary");
            System.out.println("3. Go Back to Main Menu");

            System.out.println("===================================");
            System.out.print("Enter your choice: ");
            Scanner scanner = new Scanner(System.in);
            int choice = scanner.nextInt();

            String filter_type;

            switch (choice) {
                case 1:
                    filter_type = "movie_name";
                    System.out.println("Please enter old  Movie name");
                    String text = scanner.next();
                    searchMovies(sqlConn, conn, text, filter_type);
                    break;
                case 2:
                    filter_type = "summary";
                    System.out.println("Please enter old Movie Summary ");
                    String movieSummary = scanner.next();
                    searchMovies(sqlConn, conn, movieSummary, filter_type);
                    break;

                case 3:
                    listDisplayMain(sqlConn, conn, scanner);
                    break;

                default:
                    System.out.println("Invalid choice. Please try again.");

            }
            loop = false;
        }

    }

    private static void updateMovie(SqlConnection sqlConn, Connection conn, String movie_Name, float duration_edit,
            String summary_edit, int id) {
        int result = sqlConn.updateMovie(conn, movie_Name, duration_edit, summary_edit, id);
        if (result == 1)
            System.out.println("Movie is Updated");
        else
            System.out.println("The movie wasn't Updated");
    }

    private static void createMovie(SqlConnection sqlConn, Connection conn, String movieName, float duration,
            String movieSummary) {
        int result = sqlConn.addMovie(conn, movieName, duration, movieSummary);
        if (result == 1)
            System.out.println("New movie added");
        else
            System.out.println("The movie wasn't added");
    }

    private static void getMovies(SqlConnection sqlConn, Connection conn) {
        ResultSet data = sqlConn.getMovie(conn);
        System.out.println("All Movies:");
        System.out.printf("%-4s%-40s%-10s%-50s\n", "Id", "movieName", "Duration", "movieSummary");

        try {
            while (data.next()) {
                int id = data.getInt("Id");
                String name = data.getString("Name");
                float duration = data.getFloat("Duration");
                String summary = data.getString("Summary");
                System.out.printf("%-4d%-40s%-10.2f%-50s\n", id, name, duration, summary);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

    }

    private static void closeConnection(Connection conn) {
        try {
            if (conn != null) {
                conn.close();
                System.out.println("Connection closed");
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

    }
}
