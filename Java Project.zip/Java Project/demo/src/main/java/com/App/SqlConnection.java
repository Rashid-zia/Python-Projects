package com.App;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class SqlConnection implements ISqlConnection {

    @Override
    public Connection connectToDb(String dbServer, int dbPort, String dbName, String userName, String password) {
        Connection conn = null;
        String connectionString = String.format(
                "jdbc:sqlserver://%s:%d;"
                        + "database=%s;"
                        + "user=%s;"
                        + "password=%s;"
                        + "encrypt=true;"
                        + "trustServerCertificate=false;"
                        + "loginTimeout=30;"
                        + "hostNameInCertificate=*.database.windows.net;",
                dbServer, dbPort, dbName, userName, password);

        try {
            conn = DriverManager.getConnection(connectionString);
        } catch (SQLException e) {
            System.out.println("I am here");
            System.out.println("SQL Server connection exception");
            e.printStackTrace();
        }
        return conn;
    }

    @Override
    public ResultSet getMovie(Connection conn) {
        ResultSet rs = null;
        String query = "Select * from Movies";

        try {
            Statement s = conn.createStatement();
            rs = s.executeQuery(query);

        } catch (SQLException e) {
            System.out.println("SQL Server reading exception");
            e.printStackTrace();
        }
        return rs;
    }

    @Override
    public ResultSet searchMovies(Connection conn, String search_text, String filter_type) {
        ResultSet rs = null;
        String query;

        if ("movie_name".equals(filter_type)) {
            query = "SELECT * FROM Movies WHERE Name LIKE ?";
        } else {
            query = "SELECT * FROM Movies WHERE Summary LIKE ?";
        }

        try {

            PreparedStatement ps = conn.prepareStatement(query);
            ps.setString(1, "%" + search_text + "%");
            rs = ps.executeQuery();

        } catch (SQLException e) {
            System.out.println("SQL Server reading exception");
            e.printStackTrace();
        }
        return rs;
    }

    @Override
    public int addMovie(Connection conn, String movieName, float duration, String summary) {
        int result = 0;
        String sql = String.format(
                "Insert Into Movies(Name, Duration, Summary) Values ('%s', '%f','%s')",
                movieName, duration, summary);

        try {
            Statement s = conn.createStatement();
            result = s.executeUpdate(sql);
        } catch (SQLException e) {
            System.out.println("QUERY PROBLEM");
            e.printStackTrace();
        }
        return result;
    }

    @Override
    public ResultSet getMovie(Connection conn, String Summary) {
        ResultSet rs = null;
        String query = "SELECT * FROM Movies WHERE Summary = " + Summary;

        try {
            Statement s = conn.createStatement();
            rs = s.executeQuery(query);

        } catch (SQLException e) {
            System.out.println("SQL Server reading exception");
            e.printStackTrace();
        }
        return rs;
    }

    @Override
    public int updateMovie(Connection conn, String movie_Name, float duration_edit, String summary_edit, int id) {
        int result = 0;
        String sql = "UPDATE Movies SET Name = ?, Duration = ?, Summary = ? WHERE Id = ?";

        try (PreparedStatement preparedStatement = conn.prepareStatement(sql)) {
            preparedStatement.setString(1, movie_Name);
            preparedStatement.setFloat(2, duration_edit);
            preparedStatement.setString(3, summary_edit);
            preparedStatement.setInt(4, id);
            result = preparedStatement.executeUpdate();
        } catch (SQLException e) {
            System.out.println("SQL Server update exception");
            e.printStackTrace();
        }

        return result;
    }

    @Override
    public int deleteMovie(Connection conn, int movieId) {
        int result = 0;
        String sql = "DELETE FROM Movies WHERE Id = ?";

        try (PreparedStatement preparedStatement = conn.prepareStatement(sql)) {
            preparedStatement.setInt(1, movieId);
            result = preparedStatement.executeUpdate();

            if (result > 0) {
                System.out.println("Movie with ID " + movieId + " deleted successfully.");
            } else {
                System.out.println("No movie found with ID " + movieId + ".");
            }
        } catch (SQLException e) {
            System.out.println("SQL Server delete exception");
            e.printStackTrace();
        }

        return result;
    }

    public void getMovies(Connection conn) {
    }

    public ResultSet executeQuery(Connection conn, String query) {
        return null;
    }

    @Override
    public int UpdateMovieByName(Connection conn, String movieName, String newMovieName) {
        throw new UnsupportedOperationException("Unimplemented method'UpdateMovieByName'");
    }
}
